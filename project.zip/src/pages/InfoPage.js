import React from 'react';
import { motion } from 'framer-motion';
import { Info, MapPin, Phone, Mail } from 'lucide-react';

const InfoPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pt-24 pb-12">
      <div className="container mx-auto px-4 max-w-3xl">
        <motion.h1
          className="text-4xl font-extrabold text-center text-gray-900 mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          Información de Contacto
        </motion.h1>

        <motion.div
          className="bg-white rounded-3xl shadow-2xl p-8 md:p-10 space-y-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="flex items-center gap-6">
            <motion.div 
              className="p-4 bg-blue-100 rounded-full"
              whileHover={{ scale: 1.1 }}
            >
              <MapPin className="w-8 h-8 text-blue-600" />
            </motion.div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">Nuestra Ubicación</h2>
              <p className="text-gray-600">Calle Falsa 123, Ciudad Inventada, País Imaginario</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <motion.div 
              className="p-4 bg-green-100 rounded-full"
              whileHover={{ scale: 1.1 }}
            >
              <Phone className="w-8 h-8 text-green-600" />
            </motion.div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">Llámanos</h2>
              <p className="text-gray-600">+123 456 7890</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <motion.div 
              className="p-4 bg-purple-100 rounded-full"
              whileHover={{ scale: 1.1 }}
            >
              <Mail className="w-8 h-8 text-purple-600" />
            </motion.div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">Envíanos un Email</h2>
              <p className="text-gray-600">contacto@mitienda.com</p>
            </div>
          </div>

          <div className="text-center pt-6 border-t border-gray-200">
            <p className="text-gray-700 text-lg font-semibold">¡Estamos aquí para ayudarte!</p>
            <p className="text-gray-500 mt-2">Horario de atención: Lunes a Viernes, 9:00 AM - 6:00 PM</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default InfoPage;