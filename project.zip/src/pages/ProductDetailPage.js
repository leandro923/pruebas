import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { products } from '../mock/products';
import { useCart } from '../context/CartContext';
import { Plus, Minus, ShoppingCart } from 'lucide-react';

const ProductDetailPage = () => {
  const { productId } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const product = products.find(p => p.id === productId);

  const [quantity, setQuantity] = useState(1);
  const [observations, setObservations] = useState('');

  const quantityOptions = [1, 3, 5, 10, 25];

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pt-24 pb-12">
        <h1 className="text-3xl font-bold text-gray-800">Producto no encontrado.</h1>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product, quantity, observations);
    navigate('/cart');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pt-24 pb-12">
      <div className="container mx-auto px-4 max-w-3xl">
        <motion.div
          className="bg-white rounded-3xl shadow-2xl p-8 md:p-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex flex-col md:flex-row gap-8">
            <motion.img
              src={product.image}
              alt={product.name}
              className="w-full md:w-1/2 rounded-2xl object-cover shadow-lg"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5 }}
            />
            <div className="md:w-1/2">
              <h1 className="text-4xl font-extrabold text-gray-900 mb-4">{product.name}</h1>
              <p className="text-gray-700 text-lg mb-6">{product.description}</p>
              <p className="text-3xl font-bold text-blue-600 mb-6">${product.price} por unidad</p>

              <div className="mb-6">
                <label className="block text-gray-700 font-semibold mb-2">Cantidad:</label>
                <div className="flex flex-wrap gap-3">
                  {quantityOptions.map((option) => (
                    <motion.button
                      key={option}
                      onClick={() => setQuantity(option)}
                      className={`px-5 py-3 rounded-xl font-semibold transition-all duration-200 ${
                        quantity === option
                          ? 'bg-blue-600 text-white shadow-md'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      {option} unidad{option > 1 ? 'es' : ''}
                    </motion.button>
                  ))}
                </div>
              </div>

              <div className="mb-8">
                <label htmlFor="observations" className="block text-gray-700 font-semibold mb-2">Observaciones (opcional):</label>
                <textarea
                  id="observations"
                  value={observations}
                  onChange={(e) => setObservations(e.target.value)}
                  rows="3"
                  className="w-full p-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all duration-200 text-gray-800"
                  placeholder="Ej: Sin cebolla, con extra queso, etc."
                ></textarea>
              </div>

              <motion.button
                onClick={handleAddToCart}
                className="w-full bg-green-600 text-white py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3 hover:bg-green-700 transition-colors shadow-lg"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <ShoppingCart className="w-6 h-6" />
                Agregar al Carrito
              </motion.button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ProductDetailPage;