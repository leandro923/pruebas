import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useCart } from '../context/CartContext';
import { CheckCircle2, Send } from 'lucide-react';

const CheckoutPage = () => {
  const { cartItems, getTotalPrice, clearCart } = useCart();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    address: '',
    phone: '',
    email: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const orderDetails = cartItems.map(item => {
      return `${item.product.name} (x${item.quantity}) - $${(item.product.price * item.quantity).toFixed(2)}${item.observations ? ` - Obs: ${item.observations}` : ''}`;
    }).join('\n');

    const message = `¡Hola! Me gustaría hacer un pedido:\n\n` +
                    `*Detalles del Cliente:*\n` +
                    `Nombre: ${formData.name}\n` +
                    `Dirección: ${formData.address}\n` +
                    `Teléfono: ${formData.phone}\n` +
                    `Email: ${formData.email}\n\n` +
                    `*Productos:*\n${orderDetails}\n\n` +
                    `*Total: $${getTotalPrice().toFixed(2)}*\n\n` +
                    `¡Gracias!`;

    const whatsappUrl = `https://wa.me/TU_NUMERO_DE_WHATSAPP?text=${encodeURIComponent(message)}`;
    
    window.open(whatsappUrl, '_blank');
    clearCart();
    setIsSubmitted(true);
  };

  if (cartItems.length === 0 && !isSubmitted) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pt-24 pb-12">
        <motion.div
          className="bg-white rounded-3xl shadow-2xl p-12 text-center"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <ShoppingCart className="w-24 h-24 text-gray-400 mx-auto mb-6" />
          <h1 className="text-3xl font-bold text-gray-800 mb-4">Tu carrito está vacío</h1>
          <p className="text-gray-600 mb-8">No hay nada que finalizar. ¡Añade productos primero!</p>
          <motion.button
            onClick={() => navigate('/')}
            className="bg-blue-600 text-white py-3 px-6 rounded-xl font-semibold hover:bg-blue-700 transition-colors shadow-md"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Ir a la Tienda
          </motion.button>
        </motion.div>
      </div>
    );
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pt-24 pb-12">
        <motion.div
          className="bg-white rounded-3xl shadow-2xl p-12 text-center"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <CheckCircle2 className="w-24 h-24 text-green-500 mx-auto mb-6" />
          <h1 className="text-3xl font-bold text-gray-800 mb-4">¡Pedido Enviado!</h1>
          <p className="text-gray-600 mb-8">Revisa tu WhatsApp para confirmar los detalles de tu compra.</p>
          <motion.button
            onClick={() => navigate('/')}
            className="bg-blue-600 text-white py-3 px-6 rounded-xl font-semibold hover:bg-blue-700 transition-colors shadow-md"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Volver al Inicio
          </motion.button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pt-24 pb-12">
      <div className="container mx-auto px-4 max-w-2xl">
        <motion.h1
          className="text-4xl font-extrabold text-center text-gray-900 mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          Completa tus Datos
        </motion.h1>

        <motion.div
          className="bg-white rounded-3xl shadow-2xl p-8 md:p-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-gray-700 font-semibold mb-2">Nombre Completo:</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full p-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all duration-200 text-gray-800"
                required
              />
            </div>
            <div>
              <label htmlFor="address" className="block text-gray-700 font-semibold mb-2">Dirección de Envío:</label>
              <input
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                className="w-full p-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all duration-200 text-gray-800"
                required
              />
            </div>
            <div>
              <label htmlFor="phone" className="block text-gray-700 font-semibold mb-2">Teléfono (WhatsApp):</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full p-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all duration-200 text-gray-800"
                required
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-gray-700 font-semibold mb-2">Email (Opcional):</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full p-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all duration-200 text-gray-800"
              />
            </div>

            <div className="border-t border-gray-200 pt-6 mt-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Resumen del Pedido:</h3>
              <ul className="space-y-2 mb-4">
                {cartItems.map((item) => (
                  <li key={item.product.id} className="flex justify-between text-gray-700">
                    <span>{item.product.name} (x{item.quantity})</span>
                    <span>${(item.product.price * item.quantity).toFixed(2)}</span>
                  </li>
                ))}
              </ul>
              <div className="flex justify-between items-center font-bold text-xl text-blue-700">
                <span>Total:</span>
                <span>${getTotalPrice().toFixed(2)}</span>
              </div>
            </div>

            <motion.button
              type="submit"
              className="w-full bg-green-600 text-white py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3 hover:bg-green-700 transition-colors shadow-lg"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Send className="w-6 h-6" />
              Enviar Pedido por WhatsApp
            </motion.button>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default CheckoutPage;